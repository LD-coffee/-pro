-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 05 月 21 日 00:52
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `mi`
--

-- --------------------------------------------------------

--
-- 表的结构 `pic`
--

CREATE TABLE IF NOT EXISTS `pic` (
  `sid` tinyint(1) unsigned NOT NULL,
  `pic` varchar(250) NOT NULL,
  `title` varchar(40) NOT NULL,
  `content` varchar(40) NOT NULL,
  `price` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pic`
--

INSERT INTO `pic` (`sid`, `pic`, `title`, `content`, `price`) VALUES
(4, 'https://i1.mifile.cn/a1/pms_1525853341.8312102!220x220.jpg', '红米S2 3GB+32GB', '前置1600万超大像素智能美拍', '999元'),
(5, 'https://i1.mifile.cn/a1/pms_1511228654.33099308!220x220.jpg', '小米Note 3 4GB+64GB', '1600万美颜自拍，2倍变焦双摄', '1799元 '),
(6, 'https://i1.mifile.cn/a1/pms_1512612024.50854166!220x220.jpg', '红米5 2GB+16GB', '5.7英寸全面屏，前置柔光自拍', '749元'),
(7, 'https://i1.mifile.cn/a1/pms_1495692033.10494295!220x220.jpg', '小米Max 2 4GB+64GB', '全面屏手机，4000mAh大电量', '1499元'),
(0, 'https://i1.mifile.cn/a1/pms_1525853341.8312102!220x220.jpg', '红米S2 3GB+32GB', '前置1600万超大像素智能美拍', '999元'),
(1, 'https://i1.mifile.cn/a1/pms_1511228654.33099308!220x220.jpg', '小米Note 3 4GB+64GB', '1600万美颜自拍，2倍变焦双摄', '1799元 '),
(2, 'https://i1.mifile.cn/a1/pms_1512612024.50854166!220x220.jpg', '红米5 2GB+16GB', '5.7英寸全面屏，前置柔光自拍', '749元'),
(3, 'https://i1.mifile.cn/a1/pms_1495692033.10494295!220x220.jpg', '小米Max 2 4GB+64GB', '全面屏手机，4000mAh大电量', '1499元');
